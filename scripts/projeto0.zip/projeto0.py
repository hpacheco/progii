import math
import turtle
import string

# 1.1
def perim_circ(r):
    return None

# 1.2
def area_circ(r):
    return None

# 1.3
def celsius(F):
    return None

# 1.4
def dist(x1,y1,x2,y2):
    return None

# 1.5
def radianos(graus,mins,segs):
    return None

# 1.6
def segundos(horas,mins,segs):
    return None

# 1.7

def juros(p0,r,t):
    return None

# 2.1

tempC = [-5,0,5,10,15,20,25]

def tempC1():
    for temp in tempC:
        None

def tempC2():
    for temp in range(None):
        None

def tempC3():
    None

def tempC4():
    None

# 2.2

xs = [12, 10, 32, 3, 66, 17, 42, 99, 20]

def ex22_1():
    for x in xs:
        None

def ex22_2():
    for x in xs:
        None

def ex22_3():
    None

# 2.3

def poligono_reg(t,n,lado):
    None

def test_2_3():
  window = turtle.Screen()
  alex = turtle.Turtle()
  poligono_reg(alex,3,100)
  window.mainloop()

# 2.4

def friso(t,n,lado):
    None

def test_2_4():
  window = turtle.Screen()
  alex = turtle.Turtle()
  friso(alex,2,50)
  window.mainloop()

# 2.5

def valor(v):
    return None

# 2.6


def classifica(p):
    None

# 2.7

def leibniz(k):
    """comentário"""
    return None

# 2.8

def sum_within(x,a,b):
    return None

# 2.9

def maximo2(xs):
    return None

# 2.10

def repetidos(lista):
    return None

# 2.11

def algarismos(n):
    return None

# 3.1

def conta_letras(txt):
    return None

# 3.2

def filtra_letras(txt):
    return None

# 3.3

def palindrono(txt):
    return None

# 3.4

def cesar(k,txt):
    return None


# 3.5

def remove_py_com(txt):
    return None

# 3.6

def forte(passwd):
    return None

# 3.7

def palindrono_geral_aux(txt):
    return None

def palindrono_geral(txt):
    return None

# 3.8

def ocorrencias(txt,c):
    return None








