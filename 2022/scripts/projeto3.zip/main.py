from projeto3_sols import *
# Descomentar a linha correspondente para testar cada Tarefa

# Tarefa 1
#desenhaPrecos()

# Tarefa 2
#testeDesenhaRefugiadosDia()
#desenhaRefugiadosDias()

# Tarefa 3
#desenhaPopulacaoUcrania()

# Tarefa 4

#processaEventos()
#animaEventos = Animacao(datetime.date(2022,5,10))
#animaEventos.run(20)